package com.example.sneakerlink

class DBData {
    var dataName: String? = null
    var dataTarget: String? = null

    constructor(dataName: String?, dataTarget: String?){
        this.dataName = dataName
        this.dataTarget = dataTarget
    }
    constructor()
    {}
}