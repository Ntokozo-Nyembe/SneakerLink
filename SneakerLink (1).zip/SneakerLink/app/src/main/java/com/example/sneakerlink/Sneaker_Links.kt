package com.example.sneakerlink

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Sneaker_Links : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sneaker_links)
    }
}